<?php
// =============================================
// INDEX.PHP - PTUN WEBSITE
// Redirect ke login page
// =============================================

// Redirect ke login
header('Location: login/index.php');
exit;
?>